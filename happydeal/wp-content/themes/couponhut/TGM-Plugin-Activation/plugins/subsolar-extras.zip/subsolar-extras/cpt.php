<?php
// Flush rewrite rules on activation
register_activation_hook( __FILE__, 'ssd_cpt_activation' );

// Flush rewrite rules on activation
function ssd_cpt_activation() {
	flush_rewrite_rules(true);
}

// Register Deals Post Type
function ssd_register_deal() {

	$labels = array(
		'name'               => _x( 'Deals', 'post type general name', 'subsolar' ),
		'singular_name'      => _x( 'Deal', 'post type singular name', 'subsolar' ),
		'menu_name'          => _x( 'Deals', 'admin menu', 'subsolar' ),
		'name_admin_bar'     => _x( 'Deals', 'add new on admin bar', 'subsolar' ),
		'add_new'            => _x( 'Add New', 'deal', 'subsolar' ),
		'add_new_item'       => __( 'New Deal', 'subsolar' ),
		'new_item'           => __( 'New Deal', 'subsolar' ),
		'edit_item'          => __( 'Edit Deal', 'subsolar' ),
		'view_item'          => __( 'View Deal', 'subsolar' ),
		'all_items'          => __( 'All Deals', 'subsolar' ),
		'search_items'       => __( 'Search Deals', 'subsolar' ),
		'not_found'          => __( 'No deals found.', 'subsolar' ),
		'not_found_in_trash' => __( 'No deals found in Trash.', 'subsolar' )
		);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'exclude_from_search' => true,
		'show_in_nav_menus'   => true,
		'show_in_menu'        => true,
		'query_var'           => true,
		'hierarchical'        => false,
		'menu_position'       => null,
		'supports'            => array( 'comments', 'title', 'editor' ),
		'has_archive'         => false
		);

	register_post_type( 'deal', $args );

}

function ssd_create_deal_taxonomies(){
	$categories_labels = array(
		'name'              => _x( 'Deal Categories', 'taxonomy general name' ),
		'singular_name'     => _x( 'Deal Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Deal Categories', 'subsolar' ),
		'all_items'         => __( 'All Deal Categories', 'subsolar' ),
		'parent_item'       => __( 'Parent Deal Category', 'subsolar' ),
		'parent_item_colon' => __( 'Parent Deal Category:', 'subsolar' ),
		'edit_item'         => __( 'Edit Deal Category', 'subsolar' ),
		'update_item'       => __( 'Update Deal Category', 'subsolar' ),
		'add_new_item'      => __( 'Add Deal Category', 'subsolar' ),
		'new_item_name'     => __( 'New Deal Category Name', 'subsolar' ),
		'menu_name'         => __( 'Deal Categories', 'subsolar' ),
		);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $categories_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true
		);

	register_taxonomy('deal_category', array ('deal'), $args);

	$categories_labels = array(
		'name'              => _x( 'Companies', 'taxonomy general name' ),
		'singular_name'     => _x( 'Company', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Companies', 'subsolar' ),
		'all_items'         => __( 'All Companies', 'subsolar' ),
		'edit_item'         => __( 'Edit Company', 'subsolar' ),
		'update_item'       => __( 'Update Company', 'subsolar' ),
		'add_new_item'      => __( 'Add Company', 'subsolar' ),
		'new_item_name'     => __( 'New Company Name', 'subsolar' ),
		'menu_name'         => __( 'Companies', 'subsolar' ),
		);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $categories_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		);

	register_taxonomy('deal_company', array ('deal'), $args);
}

// Register Portfolio Post Type
function ssd_register_portfolio() {

	$labels = array(
		'name' => __( 'Portfolio', 'subsolar' ),
		'singular_name' => __( 'Portfolio', 'subsolar' ),
		'add_new' => __( 'Add New', 'subsolar' ),
		'add_new_item' => __( 'Add New Portfolio', 'subsolar' ),
		'edit_item' => __( 'Edit Portfolio', 'subsolar' ),
		'new_item' => __( 'New Portfolio', 'subsolar' ),
		'view_item' => __( 'View Portfolio', 'subsolar' ),
		'search_items' => __( 'Search Portfolio Items', 'subsolar' ),
		'not_found' => __( 'No portfolio items found', 'subsolar' ),
		'not_found_in_trash' => __( 'No portfolio items found in Trash', 'subsolar' ),
		'parent_item_colon' => __( 'Parent Portfolio:', 'subsolar' ),
		'menu_name' => __( 'Portfolio', 'subsolar' ),
		);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'exclude_from_search' => true,
		'show_in_nav_menus'   => true,
		'show_in_menu'        => true,
		'query_var'           => true,
		'hierarchical'        => false,
		'menu_position'       => null,
		'supports'            => array('title','editor', 'page-attributes'),
		'has_archive'         => false,
		'rewrite'            => array( 'slug' => 'project' ),
		);

	register_post_type( 'portfolio', $args );

}

function ssd_create_portfolio_taxonomies(){
	$categories_labels = array(
		'name'              => _x( 'Portfolio Categories', 'taxonomy general name' ),
		'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Portfolio Categories', 'subsolar' ),
		'all_items'         => __( 'All Portfolio Categories', 'subsolar' ),
		'parent_item'       => __( 'Parent Portfolio Category', 'subsolar' ),
		'parent_item_colon' => __( 'Parent Portfolio Category:', 'subsolar' ),
		'edit_item'         => __( 'Edit Portfolio Category', 'subsolar' ),
		'update_item'       => __( 'Update Portfolio Category', 'subsolar' ),
		'add_new_item'      => __( 'Add Portfolio Category', 'subsolar' ),
		'new_item_name'     => __( 'New Portfolio Category Name', 'subsolar' ),
		'menu_name'         => __( 'Portfolio Categories', 'subsolar' ),
		);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $categories_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true
		);

	register_taxonomy('portfolio_category', array ('portfolio'), $args);
}
